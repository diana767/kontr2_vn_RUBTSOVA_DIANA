abstract class Abstract():Interface {
    abstract var name: String
    abstract var cena: Double
    abstract var ed: String
    abstract var vid: String
    abstract var kol: Int
    abstract var k: Int
    override fun InfoTovar()
    {

    }

    override fun OutputInfo()
    {

    }
    open fun Cennik()
    {

    }
    open fun Kategiria()
    {

    }


}

