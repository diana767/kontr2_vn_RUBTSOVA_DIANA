import kotlin.reflect.jvm.internal.impl.protobuf.ByteString
interface  Interface {
   fun InfoTovar()
   fun OutputInfo()

}